
package DaoImp;

public interface TablaDao {
    public void insert(ImpDao product);
    public void update(ImpDao product);
    public void delete(Integer BusinessEntityID);
    public void read();
}
