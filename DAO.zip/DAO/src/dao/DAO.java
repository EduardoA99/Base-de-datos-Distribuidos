
package dao;

import DaoImp.ImpDao;
import DaoImp.TablaDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DAO {
    public static void main(String[] args) {
        TablaDao product = new ImpDao();
        product.read();
        
    }
    
    }

  /*public static void main(String[] args) throws ClassNotFoundException, SQLException{
       String connectionURL = "jdbc:sqlserver://DESKTOP-I4B3KNS\\MSSQLSERVER:1433;databaseName=AdventureWorks2019;user=pruebalogin;password=123;";
       Connection con = DriverManager.getConnection(connectionURL);
       System.out.println("Nos conectamos");
       
       Statement st = con.createStatement();
       ResultSet rs = st.executeQuery("select * from Sales.Store");
       
       while(rs.next()){
           int BusinessEntityID = rs.getInt(1);
           String Name = rs.getString(2);
           int SalesPersonID = rs.getInt(3);
           String Demographics = rs.getString(4);
           String rowguid = rs.getString(5);
           String ModifiedDate = rs.getString(6);
           System.out.println(BusinessEntityID + " " + Name + " " + SalesPersonID + " " + Demographics + " " + rowguid + " " + ModifiedDate);
     }
    }*/