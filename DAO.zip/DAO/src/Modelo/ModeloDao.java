
package Modelo;

public class ModeloDao {
    
    private Integer BusinessEntityID;
    private String Name;
    private Integer SalesPersonID;
    private String Demographics;
    private String rowguid;
    private String ModifiedDate;

    public ModeloDao(int BusinessEntityID, String Name, Integer SalesPersonID, String Demographics, String rowguid, String ModifiedDate) {
        this.BusinessEntityID = BusinessEntityID;
        this.Name = Name;
        this.SalesPersonID = SalesPersonID;
        this.Demographics = Demographics;
        this.rowguid = rowguid;
        this.ModifiedDate = ModifiedDate;
    }

}
